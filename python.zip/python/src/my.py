from db.dao import HBaseDao

#cardId = 340028465709212

myDao = HBaseDao.get_instance()
#table ='card_transaction_lookup'
#key = cardId
#ccTransactionRow = myDao.get_data(key, table)
#print (ccTransactionRow)

def write_data():
	cardId = 340028465709212
	amount = 9084849
	postcode = 33946
	posId = 614677375609919
	tran_dt = '15-02-2018  00:00:00'
	status = 'GENUINE'
	lookuptable = 'card_transaction_lookup'
	tranmastertable = 'card_transactions_master'
	key = str(cardId)
	card_transaction_dict = {}
	card_transaction_dict['transactionDetail:status'] = str(status)
	card_transaction_dict['transactionDetail:transaction_dt'] = str(transaction_dt)
	card_transaction_dict['transactionDetail:pos_id'] = str(posId)
	card_transaction_dict['transactionDetail:postcode'] = str(postcode)
	card_transaction_dict['transactionDetail:amount'] = str(amount)
	card_transaction_dict['cardDetail:member_id'] = str(0)
	card_transaction_dict['cardDetail:card_id'] = str(cardId)

	print(key)
	print (card_transaction_dict)
	print(tranmastertable)
#	myDao.write_data(key,card_transaction_dict, tranmastertable)
	print("done with insert")


def read_data():
        table = 'card_transactions_master'
#        cardId = 340028465709212
	cardId = 5258095619226135
        key = str(cardId)
	ccTransactionRow = myDao.get_data(key, table)
	print (ccTransactionRow)


def write_lookup_data():
#        cardId = 340028465709212 
	cardId = 1121
        ucl = 1.3615702233959382E7    
        postcode = 9225021   
        transaction_dt = '31-07-2017 22:37:30'
        score = 243
        lookuptable = 'card_transaction_lookup'
        tranmastertable = 'card_transactions_master'
        key = str(cardId)
        card_transaction_dict = {}
#        card_transaction_dict['cf:score'] = str(score)
        card_transaction_dict['cf:transaction_dt'] = str(transaction_dt)
        card_transaction_dict['cf:postcode'] = str(postcode)
#        card_transaction_dict['cf:ucl'] = str(ucl)
#        card_transaction_dict['cf:card_id'] = str(cardId)
        print(key)
        print (card_transaction_dict)
        print(lookuptable)
        myDao.write_data(key,card_transaction_dict, lookuptable)
        print("done with insert")

def read_lookup_data():
        table = 'card_transaction_lookup'
#        cardId = 340028465709212
        cardId = 1121
        key = str(cardId)
        ccTransactionRow = myDao.get_data(key, table)
        print (ccTransactionRow)


def remove_lookup_data():
        table = 'card_transactions_master'
        cardId = 340028465709212
        key = str(cardId)
        myDao.remove_data(key, table)




#read_data()
#write_data()
#write_lookup_data()
#read_lookup_data()
remove_lookup_data()
