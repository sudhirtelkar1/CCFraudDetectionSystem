#export SPARK_KAFKA_VERSION=0.10
#spark2-submit --py-files src.zip --jars spark-sql-kafka-0-10_2.11-2.3.0.jar --files uszipsv.csv driver.py

# Importing Dependencies
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from rules.rules  import CC_Rules


# STEP 1 : INITIALISE THE APPLICATION 
# Initialize Spark session
spark = SparkSession \
   .builder \
   .appName("CreditCardFraudDetection") \
   .getOrCreate()
spark.sparkContext.setLogLevel('ERROR')	


    
# STEP 2 : READING INPUT DATA FROM KAFKA

# Define the Schema 
creditcardSchema = StructType() \
    .add("card_id", LongType()) \
    .add("member_id", LongType()) \
    .add("amount", DoubleType()) \
    .add("postcode", IntegerType()) \
    .add("pos_id", LongType()) \
    .add("transaction_dt", StringType()) 



# Connect to Kafka Broker and read from Kafka Topic
creditcarddatakafka = spark  \
	.readStream  \
	.format("kafka")  \
	.option("kafka.bootstrap.servers","18.211.252.152:9092")  \
        .option("startingOffsets","earliest") \
	.option("subscribe","transactions-topic-verified")  \
	.load() \


kafkaDF = creditcarddatakafka.selectExpr("CAST(value AS STRING) as bms_data1") \
                      .select(from_json("bms_data1", creditcardSchema).alias("CCTransaction")) \
                      .select("CCTransaction.*")




# STEP 3 : INITIALISE OBJECTS, APPLY RULES AND ADD RESULT TO DATAFRAME

#Intialize the objects
myRules = CC_Rules.get_instance()

# Create UDF functions
def apply_rules(card_id, amount, pos_id, postcode, transaction_dt ):
    rulesresult  = myRules.isTransactionValid(card_id, amount, pos_id, postcode, transaction_dt )
    return rulesresult

applyrulesUDF = udf(apply_rules, StringType())

cctransactionDF = kafkaDF.withColumn("transactiontype", applyrulesUDF(kafkaDF.card_id, kafkaDF.amount, kafkaDF.pos_id, kafkaDF.postcode, kafkaDF.transaction_dt)) 
query = cctransactionDF  \
        .writeStream  \
        .outputMode("append")  \
        .format("console")  \
        .start()

query.awaitTermination()

