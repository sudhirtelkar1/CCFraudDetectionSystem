import math
import datetime
from db.geo_map import GEO_Map
from db.dao import HBaseDao

class CC_Rules():

	__instance = None

	@staticmethod
	def get_instance():
		""" Static access method. """
		if CC_Rules.__instance == None:
			CC_Rules()
		return CC_Rules.__instance

	def __init__(self):
		""" Virtually private constructor. """
		if CC_Rules.__instance != None:
			raise Exception("This class is a singleton!")
		else:
			CC_Rules.__instance = self
			# Initialise objects
			global my_GeoMap
			global myDao
			my_GeoMap = GEO_Map.get_instance()
			myDao = HBaseDao.get_instance()

	

	def getIsUCLValid(self, amt, lookupUCL) :
		isUCLValid = True
		if (amt > lookupUCL):
			isUCLValid = False
		return isUCLValid
		
	def getIsScoreValid(self,Score):
		isScoreValid = True
		scorethreshhold = 200
		if (Score < scorethreshhold):
			isScoreValid = False
		return isScoreValid
		
	# lookup record based on cardId key
	def getLookupRow(self, cardId ):	
		table = 'card_transaction_lookup'
		key = cardId
		myDao = HBaseDao.get_instance()
		ccTransactionRow = myDao.get_data(key, table)
		return ccTransactionRow
		

	def convert_to_date(self, stringdate) :
		#handle null and wrongly formed stringdate 
		date_time_obj = datetime.datetime.strptime(stringdate, '%d-%m-%Y  %H:%M:%S')
		return date_time_obj

		
	def get_CCTransactionTime(self, transaction_dt, lookup_dt) :
		#handle scneario where transaction_dt or lookup_dt is wrongly formed data
		diffSeconds = 0
		transaction_date = self.convert_to_date(transaction_dt)
		lookup_date = self.convert_to_date(lookup_dt)
		diffSeconds = (transaction_date - lookup_date).total_seconds() / 1000
		return diffSeconds

	def getIsSpeedValid(self,ccTransactionDistance, ccTransactionTime ):
		isSpeedValid = True
		ccspeed = 0
		if (ccTransactionTime == 0):
			ccspeed = 0
		else :
			ccspeed = ccTransactionDistance / ccTransactionTime;
		threshhold =4 
		if (ccspeed > threshhold ) :
			isSpeedValid = False
		return isSpeedValid
	

	def update_lookup_table(self, cardId, postcode, transaction_dt):
		#Handle exception from happybase
        	lookuptable = 'card_transaction_lookup'
	        key = str(cardId)
        	card_transaction_dict = {}
	        card_transaction_dict['cf:transaction_dt'] = str(transaction_dt)
        	card_transaction_dict['cf:postcode'] = str(postcode)
		myDao = HBaseDao.get_instance()
	        myDao.write_data(key,card_transaction_dict, lookuptable)

        def append_transactions_master(self, cardId, amount, postcode, posId, transaction_dt, status ):
		#Handle exception from happybase
		tranmastertable = 'card_transactions_master'
		key = str(cardId)
		card_transaction_dict = {}
		card_transaction_dict['transactionDetail:status'] = str(status)
		card_transaction_dict['transactionDetail:transaction_dt'] = str(transaction_dt)
		card_transaction_dict['transactionDetail:pos_id'] = str(posId)
		card_transaction_dict['transactionDetail:postcode'] = str(postcode)
		card_transaction_dict['transactionDetail:amount'] = str(amount)
		card_transaction_dict['cardDetail:member_id'] = str(0)
		card_transaction_dict['cardDetail:card_id'] = str(cardId)
		myDao = HBaseDao.get_instance()
		myDao.write_data(key,card_transaction_dict, tranmastertable)


	
	# validate Transaction - returns boolean 	
	def isTransactionValid(self, cardId, amount, posId, postcode, tran_dt):	
        	#status record
		status = "GENUINE"
		#pull up the lookup record
		lookupRow = self.getLookupRow(str(cardId))
		lookupdt = lookupRow['cf:transaction_dt']
		lookuppostcode = lookupRow['cf:postcode']
		lookupUCL = lookupRow['cf:ucl']
		lookupscore = lookupRow['cf:score']
		CCTransactionTime = self.get_CCTransactionTime(tran_dt, lookupdt)
		lookuppostcode = lookupRow['cf:postcode']
		#print (CCTransactionTime)
		my_GeoMap = GEO_Map.get_instance()
		CCTransactionDistance = my_GeoMap.get_DistanceViaPosId(postcode, lookuppostcode)
		#print (CCTransactionDistance)
		isSpeedValid =  self.getIsSpeedValid(CCTransactionDistance, CCTransactionTime )
		#print (isSpeedValid)
		isUCLValid = self.getIsUCLValid(amount, lookupUCL)
		#print(isUCLValid)
		isScoreValid =self.getIsScoreValid(lookupscore)
		#print(isScoreValid)
		if not (isUCLValid and isScoreValid and isSpeedValid ) :
		        status = "FRAUD"
		#Write to transaction master
		self.append_transactions_master(cardId, amount, postcode, posId, tran_dt, status )
		if (status == "GENUINE"):
			# update lookup table 
			self.update_lookup_table( cardId, postcode, tran_dt)
		return status        		


		










