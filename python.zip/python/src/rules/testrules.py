from rules  import CC_Rules

#Intialize the objects
myRules = CC_Rules.get_instance()
card_id = '340028465709212'
amount = 9084849
pos_id = 614677375609919
postcode = 33946
transaction_dt = "15-02-2018  00:00:00"

rulesresult = myRules.isTransactionValid(card_id, amount, pos_id, postcode, transaction_dt )

print(rulesresult)
